﻿public class Licuado

{
    public int Leche;
    public int Azucar;
    public bool Agrandado;
    double precioFijo = 20;
    double precioAzucarBlanca = 0.60;
    double precioAzucarMorena = 0.40;
    double precioSuplemento = 0.90;
    

    public Licuado(int leche, int cucharadasAzucar, int tipoAzucar)
    {
        Leche = leche;
        Azucar = cucharadasAzucar;
        Agrandado = false;
        cucharadasAzucar = 0;
        tipoAzucar = 0;

    }
  
    static double nuevoPrecioBlanca( double precioFijo, double precioAzucarBlanca, double cucharadasAzucarB)
    {
        return (precioAzucarBlanca*cucharadasAzucarB)+precioFijo; 
    }
   
    static double nuevoPrecioMorena( double precioFijo, double precioAzucarMorena, double cucharadasAzucarM)
    {
        return (precioAzucarMorena*cucharadasAzucarM)+precioFijo; 
    }
    
    static double nuevoPrecioSuplemento( double precioFijo, double precioSuplemento, double cucharadasAzucarS)
    {
       return (precioSuplemento*cucharadasAzucarS)+precioFijo; 
    }
   

}