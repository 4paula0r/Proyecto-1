﻿namespace Proyecto_1_Pensamiento_Computacional_SEM1;

public class Persona
{
    public string Nombre;
    public string Apellido;
    public Persona (string nombre, string apellido)
    {
        Nombre = nombre;
        Apellido = apellido;    
    }
    static int NIT(int nit)
    {
        return nit;
    }
}
